/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This class implements a server using TCP.
 * It generates user ID using the RSA public key and send it to the server for verification
 *
 */
import java.io.*;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;

public class VerifyingServerTCP {
    private static Map<String, Integer> map = new TreeMap<>();
    private static BigInteger e, n;

    /**
     * The main method of the server program. It prompts the user to input the
     * port number to use for the connection and then communicate with a client.
     * It receives request from client and call functions to perform the service,
     * and then reply to the client with the result
     * The program don't stop even if the client side is down.
     *
     * @param args command-line arguments, not used in this program
     */
    public static void main(String args[]) {
        System.out.println("Server started.");

        // Prompt user to enter port number to listen on
        System.out.println("Enter port number: ");
        Scanner sc = new Scanner(System.in);
        int serverPort = sc.nextInt();

        Socket clientSocket = null;
        ServerSocket listenSocket;

        try {
            // Create a new server socket
            listenSocket = new ServerSocket(serverPort);

            /*
             * Block waiting for a new connection request from a client.
             * When the request is received, "accept" it, and the rest
             * the tcp protocol handshake will then take place, making
             * the socket ready for reading and writing.
             */
            while(true){
                // Create a new server socket
                clientSocket = listenSocket.accept();
                // If we get here, then we are now connected to a client.

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

                String res = null;

                // This loop will continue as long as there is input from the input stream (in)
                while (in.hasNextLine()) {
                    // Read a line of input from the client socket
                    String data = in.nextLine();

                    // Split the input into separate values
                    String[] inputs = data.split(",");

                    // Parse the input stream values
                    int choice = Integer.parseInt(inputs[0]);
                    String id = inputs[1];

                    // Get the public of the client
                    String public_key = inputs[2];
                    e = new BigInteger(public_key.substring(0, 5));
                    n = new BigInteger(public_key.substring(5));

                    System.out.println("e is " + e);
                    System.out.println("n is " + n);
                    System.out.println("Client's public key is " + public_key + "\n");
                    // Get the signature of the client
                    String signature = inputs[3];

                    int value = 0;

                    // Set the value for the operation requested if the user choose "add" or "subtract"
                    if(choice != 3)
                        value = Integer.parseInt(inputs[4]);

                    /*
                    The server will make two checks before servicing any client request.
                    First, does the public key hash to the ID?
                    Second, is the request properly signed?
                    If both of these are true, the request is carried out on behalf of the client.
                     */
                    // Check if the ID matches the hash of the public_key
                    if(verifyID(public_key, id)){
                        System.out.println("The client's user ID has been verified.");

                        // When user chooses "add"
                        if (choice == 1) {
                            // Check if the request is signed
                            String messageToCheck = choice + id + public_key + value;
                            if(verify(messageToCheck, signature)) {
                                System.out.println("The signature has been verified.\n");
                                System.out.println("Operation request: add");

                                // Perform operation
                                res = String.valueOf(add(id, value));
                                // Print out the result
                                System.out.println("Returning sum of " + res + " to client");
                                System.out.println("");
                            }

                            // When user chooses "subtract"
                        } else if (choice == 2) {
                            // Check if the request is signed
                            if(verify(choice + id + public_key + value, signature)) {
                                System.out.println("The signature has been verified.");
                                System.out.println("Operation request: subtract");

                                // Perform operation
                                res = String.valueOf(subtract(id, value));
                                // Print out the result
                                System.out.println("Returning sum of " + res + " to client");
                                System.out.println("");
                            }
                            // When user chooses "get"
                        } else {
                            if(verify(choice + id + public_key, signature)) {
                                System.out.println("The signature has been verified.");
                                System.out.println("Operation request: get");

                                // Perform operation
                                res = String.valueOf(get(id));
                                // Print out the result
                                System.out.println("Returning sum of " + res + " to client");
                                System.out.println("");
                            }
                        }
                    }

                    out.println(res);
                    out.flush();
                }
            }
            // Handle exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting (typically by you sending quit signal) clean up sockets
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

    /**
     * Adds the specified value to the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be added to the current value associated with the ID
     * @return the new value associated with the ID after the addition
     */
    public static int add(String id, int value){
        map.put(id, map.getOrDefault(id, 0) + value);
        return map.get(id);
    }

    /**
     * Subtracts the specified value from the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be subtracted from the current value associated with the ID
     * @return the new value associated with the ID after the subtraction
     */
    public static int subtract(String id, int value){
        map.put(id, map.getOrDefault(id, 0) - value);
        return map.get(id);
    }

    /**
     * Retrieves the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be retrieved
     * @return the current value associated with the ID
     */
    public static int get(String id){
        return map.getOrDefault(id, 0);
    }

    /**
     * Reference: ShortMessageVerify.java
     * Verifying proceeds as follows:
     * 1) Decrypt the encryptedHash to compute a decryptedHash
     * 2) Hash the messageToCheck using SHA-256 (be sure to handle
     *    the extra byte as described in the signing method.)
     * 3) If this new hash is equal to the decryptedHash, return true else false.
     *
     * @param messageToCheck  a normal string that needs to be verified.
     * @param encryptedHashStr integer string - possible evidence attesting to its origin.
     * @return true or false depending on whether the verification was a success
     * @throws Exception
     */
    public static boolean verify(String messageToCheck, String encryptedHashStr)  {
        // Take the encrypted string and make it a big integer
        BigInteger encryptedHash = new BigInteger(encryptedHashStr);

        // Decrypt it
        BigInteger decryptedHash = encryptedHash.modPow(e, n);

        // Get the bytes from messageToCheck
        byte[] bytesOfMessageToCheck = new byte[0];

        try {
            // Convert string to an array of bytes using the UTF-8 character encoding
            bytesOfMessageToCheck = messageToCheck.getBytes("UTF-8");

            // compute the digest of the message with SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // Returns a byte array representing the hash value of the input
            byte[] messageToCheckDigest = md.digest(bytesOfMessageToCheck);

            // messageToCheckDigest is a full SHA-256 digest
            // Add a zero byte at the beginning of the byte array
            byte[] extraByte = new byte[messageToCheckDigest.length + 1];
            extraByte[0] = 0;

            // Take all bytes from the digest
            for(int i = 1; i < messageToCheckDigest.length + 1; i++){
                extraByte[i] = messageToCheckDigest[i - 1];
            }

            // Make it a big int
            BigInteger bigIntegerToCheck = new BigInteger(extraByte);

            // inform the client on how the two compare
            if(bigIntegerToCheck.compareTo(decryptedHash) == 0) {
                return true;
            }
            else {
                return false;
            }

            // Catche exceptions
        } catch (UnsupportedEncodingException exception) {
            System.out.println(exception.getMessage());
        } catch (NoSuchAlgorithmException exception) {
            System.out.println(exception.getMessage());
        }

        return false;
    }

    // Code from stack overflow
    // https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    // Returns a hex string given an array of bytes
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

    /**
     * Verifies if a given ID matches the expected ID derived from a public key hash.
     *
     * @param public_key the public key to use for deriving the expected ID
     * @param id the ID to verify against the expected ID
     * @return true if the ID matches the expected ID, false otherwise
     */
    public static boolean verifyID(String public_key, String id){
        // Access MessageDigest class for SHA-265
        MessageDigest md = null;
        try {
            // compute the digest of the message with SHA-256
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException ex) {
            System.out.println(ex.getMessage());
        }

        // Hash the public key with SHA-256
        byte[] digest = md.digest(public_key.getBytes());

        // Take the least significant 20 bytes of the hash to form client's ID
        byte[] testIdBytes = Arrays.copyOfRange(digest, 12, 32);

        // Return ID by converting the last 20 bytes  into a hex string
        String testID = bytesToHex(testIdBytes);

        // Return true if the ID is the least significant 20 bytes of the public key, else return false
        if(id.equals(testID))
            return true;
        else
            return false;

    }
}
