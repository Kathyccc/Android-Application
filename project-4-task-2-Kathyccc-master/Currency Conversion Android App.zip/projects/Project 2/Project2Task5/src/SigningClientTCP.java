/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This program demonstrates a TCP client
 * It maps each user ID to the value of a sum
 * The server operate addition, subtraction and get the value of current sum for each user
 * It uses RSA public key to verify the message sent by the client
 */
import java.io.*;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
Each time the client program runs,
it will create new RSA public and private keys and display these keys to the user.
After the client program creates and displays these keys,
it interacts with the user and the server.
 */

public class SigningClientTCP {
    private static Socket clientSocket;
    private static BufferedReader in;
    private static PrintWriter out;
    private static String public_key;
    private static String private_key;

    // Each public and private key consists of an exponent and a modulus
    private static BigInteger n; // n is the modulus for both the private and public keys
    private static BigInteger e; // e is the exponent of the public key
    private static BigInteger d; // d is the exponent of the private key
    private static String id;

    /**
     * The main method of the client program. It prompts the user to input the
     * port number to use for the connection and then presents a menu of options
     * for interacting with the server. The user can choose to add, subtract or
     * get a value associated with an ID. The user can also choose to exit the
     * program, which closes the socket connection to the server.
     *
     * @param args command-line arguments, not used in this program
     */

    public static void main(String[] args)  {
        System.out.println("The client is running.");

        // Prompt user to enter port number to listen on
        System.out.println("Enter port number: ");
        Scanner sc = new Scanner(System.in);
        int serverPort = sc.nextInt();

        // Generate e, d, n to form the public key as well as the private key
        generateID();

        try {
            // Connect to server socket
            clientSocket = new Socket("localhost", serverPort);
            boolean run = true;

            // loop until the user asks to exit the program
            while (run) {
                // Print menu to user
                System.out.println("1. Add a value to your sum.\n" +
                        "2. Subtract a value from your sum.\n" +
                        "3. Get your sum.\n" +
                        "4. Exit client.");

                // Take user input for menu choice
                int choice = sc.nextInt();

                // Initialize variables for later use
                int replyInt;
                int value;

                // Process user's choice
                switch(choice) {
                    case 1:
                        // User chooses to add a value to their sum
                        System.out.println("Enter value to add: ");
                        value = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);
                        System.out.println("The result is " + replyInt + ".\n");
                        break;

                    case 2:
                        // User chooses to subtract a value from their sum
                        System.out.println("Enter value to subtract: ");
                        value = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);

                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 3:
                        /*
                        User chooses to get their sum
                        Send request to server and get response
                        Set the value to zero because it won't be used for get operation
                         */
                        replyInt = operationRequest(choice, id, 0);
                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 4:
                        // User chooses to exit client
                        run = false;
                        break;

                    default:
                        // User inputs invalid choice
                        System.out.println("Please choose from the menu");
                        break;
                }

                // If user has chosen to exit, break out of loop
                if(!run){
                    break;
                }
            }
        } catch (IOException ioException) {
            System.out.println(ioException.getMessage());
        } finally {
            // Close the client socket
            try {
                if (clientSocket != null) {
                    System.out.println("Client side quitting. The remote variable server is still running.\n");
                    clientSocket.close();
                }
            } catch (IOException ioException) {
                // ignore exception on close
            }
        }
    }

    /**
     * Reference: ShortMessageSign.java
     * Signing proceeds as follows:
     * 1) Get the bytes from the string to be signed.
     * 2) Compute a SHA-256 digest of these bytes.
     * 3) Copy these bytes into a byte array that is one byte longer than needed.
     *    The resulting byte array has its extra byte set to zero. This is because
     *    RSA works only on positive numbers. The most significant byte (in the
     *    new byte array) is the 0'th byte. It must be set to zero.
     * 4) Create a BigInteger from the byte array.
     * 5) Encrypt the BigInteger with RSA d and n.
     * 6) Return to the caller a String representation of this BigInteger.
     * @param message a sting to be signed
     * @return a string representing a big integer - the encrypted hash.
     */
    public static String sign(String message)  {
        BigInteger c = null;

        try {
            // Convert string to an array of bytes using the UTF-8 character encoding
            byte[] bytesOfMessage = message.getBytes("UTF-8");

            // compute the digest of the message with SHA-256
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // Returns a byte array representing the hash value of the input
            byte[] bigDigest = md.digest(bytesOfMessage);

            // Create a new digest and add a 0 byte as the most significant
            // byte to keep the value to be non-negative
            byte[] messageDigest = new byte[bigDigest.length + 1];

            // most significant set to 0
            messageDigest[0] = 0;

            // Loop over the original digest and put into the new one
            for (int i = 1; i < bigDigest.length + 1; i++) {
                messageDigest[i] = bigDigest[i - 1];
            }

            // From the digest, create a BigInteger
            BigInteger m = new BigInteger(messageDigest);

            // encrypt the digest with the private key
            c = m.modPow(d, n);

            // Catche exceptions
        } catch (UnsupportedEncodingException ex) {
            System.out.println(ex.getMessage());
        } catch (NoSuchAlgorithmException ex) {
           System.out.println(ex.getMessage());
        }

        // return this as a big integer string
        return c.toString();
    }

    /**
     * Sends an operation request to the server and returns the server's response.
     *
     * @param choice the type of operation to perform
     * @param id the ID associated with the data to be read or written
     * @param value the value to be written (if performing a write operation)
     * @return the server's response to the operation request
     */
    public static int operationRequest(int choice, String id, int value){
        String res = null;
        String message;

        // Add a 0 byte at the beginning to ensure the value to be positive
        if(choice == 1 || choice == 2)
            message = choice + id + public_key + value;
        else
            message = choice + id + public_key;

        // Calls the sign method to generate a signature for the message.
        String signature = sign(message);

        try {
            // Creates a new BufferedReader to read data from the socket input stream.
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // Creates a new PrintWriter to write data to the socket output stream.
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            // Constructs the message for sending to server by concatenating the values of the choice, id, and value parameters.
            String m;
            if(choice == 1 || choice == 2)
                m =  choice + "," + id + "," + public_key + "," + signature + "," + value ;
            else
                m = choice + "," + id + "," + public_key + "," + signature;

            // Send the response back to the client
            out.println(m);

            // Flushes the PrintWriter to ensure that all characters are written to the output stream.
            out.flush();

            // read a line of data from the stream
            res = in.readLine();
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }

        return Integer.parseInt(res);
    }

    /**
     * Reference: RSAExample.java
     * Generates a pair of public and private keys for use in RSA encryption and SHA-256 hash function.
     *
     * @throws NoSuchAlgorithmException If SHA-256 algorithm is not found
     */
    public static void generateID(){
        Random rnd = new Random();

        // Generate two large random primes.
        // We use 400 bits here, but best practice for security is 2048 bits.
        // Change 400 to 2048, recompile, and run the program again and you will
        // notice it takes much longer to do the math with that many bits.
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);

        // Compute n by the equation n = p * q.
        n = p.multiply(q);

        // Compute phi(n) = (p-1) * (q-1)
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));

        // Select a small odd integer e that is relatively prime to phi(n).
        // By convention the prime 65537 is used as the public exponent.
        e = new BigInteger("65537");

        // Compute d as the multiplicative inverse of e modulo phi(n).
        d = e.modInverse(phi);

        // Concatenate e and n to form a public key
        public_key = e.toString() + n.toString();

        System.out.println("e is " + e);
        System.out.println("n is " + n);
        System.out.println("d is " + d + "\n");

        System.out.println("The client's public key is " + public_key);

        // Concatenation of d and n to form a private key
        private_key = d.toString() + n.toString();

        System.out.println("The client's private key is " + private_key);

        // Access MessageDigest class for SHA-265
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("SHA-256");
        } catch (NoSuchAlgorithmException ex) {
            System.out.println(ex.getMessage());
        }

        // Hash the public key with SHA-256
        byte[] digest = md.digest(public_key.getBytes());

        // Take the least significant 20 bytes of the hash to form client's ID
        byte[] id_bytes = Arrays.copyOfRange(digest, 12, 32);

        // Return ID by converting the last 20 bytes  into a hex string
        id = bytesToHex(id_bytes);

        System.out.println("User ID is " + id + "\n");
    }

    // Code from stack overflow
    // https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    // Returns a hex string given an array of bytes
    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }

}
