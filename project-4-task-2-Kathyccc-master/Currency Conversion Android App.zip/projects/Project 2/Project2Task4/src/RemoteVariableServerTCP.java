/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This program demonstrates a TCP server
 * It maps each user ID to the value of a sum.
 * The server operate addition, subtraction and get the value of current sum for each user.
 */
import java.net.*;
import java.io.*;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class RemoteVariableServerTCP {
    // Create a map to store user id and the current sum for each user
    private static Map<Integer, Integer> map = new TreeMap<>();

    /**
     * The main method of the server program. It prompts the user to input the
     * port number to use for the connection and then communicate with a client.
     * It receives request from client and call functions to perform the service,
     * and then reply to the client with the result
     * The program don't stop even if the client side is down.
     *
     * @param args command-line arguments, not used in this program
     */
    public static void main(String args[]) {
        System.out.println("Server started.");

        // Prompt user to enter port number to listen on
        System.out.println("Enter port number: ");
        Scanner sc = new Scanner(System.in);
        int serverPort = sc.nextInt();

        Socket clientSocket = null;
        ServerSocket listenSocket;

        try {
            // Create a new server socket
            listenSocket = new ServerSocket(serverPort);

            /*
             * Block waiting for a new connection request from a client.
             * When the request is received, "accept" it, and the rest
             * the tcp protocol handshake will then take place, making
             * the socket ready for reading and writing.
             */

            // Wait for incoming client connections
            while(true){
                // If we get here, then we are now connected to a client.
                clientSocket = listenSocket.accept();

                // Set up "in" to read from the client socket
                Scanner in;
                in = new Scanner(clientSocket.getInputStream());

                // Set up "out" to write to the client socket
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

                // Initialize the operation result for later use
                String res;

                // This loop will continue as long as there is input from the input stream (in)
                while (in.hasNextLine()) {
                    // Read a line of input from the client socket
                    String data = in.nextLine();

                    // Split the input into separate values
                    String[] inputs = data.split(",");

                    // Parse the input values
                    int choice = Integer.parseInt(inputs[0]);
                    int id = Integer.parseInt(inputs[1]);
                    int value = Integer.parseInt(inputs[2]);

                    System.out.println("User ID: " + id);

                    // Perform the requested operation (addition, subtraction, or get)
                    if (choice == 1) {
                        System.out.println("Operation request: add");

                        res = String.valueOf(add(id, value));
                        // Print out the result
                        System.out.println("Returning sum of " + res + " to client");
                        System.out.println("");

                    } else if (choice == 2) {
                        System.out.println("Operation request: subtract");

                        res = String.valueOf(subtract(id, value));
                        // Print out the result
                        System.out.println("Returning sum of " + res + " to client");
                        System.out.println("");
                    } else {
                        System.out.println("Operation request: get");

                        res = String.valueOf(get(id));
                        // Print out the result
                        System.out.println("Returning sum of " + res + " to client");
                        System.out.println("");
                    }

                    // Send the response back to the client
                    out.println(res);

                    // Flushes the PrintWriter to ensure that all characters are written to the output stream.
                    out.flush();
                }
            }

            // Handle exceptions
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());

            // If quitting, clean up sockets
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }
    /**
     * Adds the specified value to the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be added to the current value associated with the ID
     * @return the new value associated with the ID after the addition
     */
    public static int add(int id, int value){
        map.put(id, map.getOrDefault(id, 0) + value);
        return map.get(id);
    }

    /**
     * Subtracts the specified value from the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be subtracted from the current value associated with the ID
     * @return the new value associated with the ID after the subtraction
     */
    public static int subtract(int id, int value){
        map.put(id, map.getOrDefault(id, 0) - value);
        return map.get(id);
    }

    /**
     * Retrieves the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be retrieved
     * @return the current value associated with the ID
     */
    public static int get(int id){
        return map.getOrDefault(id, 0);
    }
}