/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This class implements a client for a remote variable server using TCP.
 * The client communicates with the server over a socket connection and
 * allows the user to add, subtract or get a value associated with an ID.
 * The client presents a menu to the user for each interaction and waits for
 * user input. The client sends a request to the server based on user input
 * and displays the result received from the server.
 */

import java.net.*;
import java.io.*;
import java.util.Scanner;

public class RemoteVariableClientTCP {
    static Socket clientSocket = null;
    static BufferedReader in;
    static PrintWriter out;
    static int serverPort;

    /**
     * The main method of the client program. It prompts the user to input the
     * port number to use for the connection and then presents a menu of options
     * for interacting with the server. The user can choose to add, subtract or
     * get a value associated with an ID. The user can also choose to exit the
     * program, which closes the socket connection to the server.
     *
     * @param args command-line arguments, not used in this program
     */
    public static void main(String args[]) {
        System.out.println("The client is running.");

        // Prompt user to enter port number to listen on
        System.out.println("Enter port number: ");
        Scanner sc = new Scanner(System.in);
        serverPort = sc.nextInt();

        try {
            // Declare static variables that will be used to establish a connection with the server
            clientSocket = new Socket("localhost", serverPort);

            boolean run = true;

            while (run) {
                // Print menu to user
                System.out.println("1. Add a value to your sum.\n" +
                        "2. Subtract a value from your sum.\n" +
                        "3. Get your sum.\n" +
                        "4. Exit client.");

                // Take user input for menu choice
                int choice = sc.nextInt();

                // Initialize variables for later use
                int replyInt;
                int id;
                int value;

                // Process user's choice
                switch(choice) {
                    case 1:
                        // User chooses to add a value to their sum
                        System.out.println("Enter value to add: ");
                        value = sc.nextInt();

                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);
                        System.out.println("The result is " + replyInt + ".\n");
                        break;

                    case 2:
                        // User chooses to subtract a value from their sum
                        System.out.println("Enter value to subtract: ");
                        value = sc.nextInt();

                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);

                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 3:
                        // User chooses to get their sum
                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        /*
                        Send request to server and get response
                        Set the value to zero because it won't be used for get operation
                         */
                        replyInt = operationRequest(choice, id, 0);

                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 4:
                        // User chooses to exit client
                        run = false;
                        break;

                    default:
                        // User inputs invalid choice
                        System.out.println("Please choose from the menu");
                        break;
                }

                // If user has chosen to exit, break out of loop
                if(!run){
                    break;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (clientSocket != null) {
                    System.out.println("Client side quitting. The remote variable server is still running.\n");
                    clientSocket.close();
                }
            } catch (IOException e) {
                // ignore exception on close
            }
        }
    }

    /**
     * Sends a request to a server over a network connection and returns the response.
     * Each request asks the server to do "add" or "subtract" or "get"
     * Receive the operation results from the server's reply
     *
     * @param choice the choice associated with the request
     * @param id the ID associated with the request
     * @param value the value associated with the request
     * @return the response from the server
     */
    public static int operationRequest(int choice, int id, int value){
        String res = null;

        try {
            // Creates a new BufferedReader object that reads from the input stream of the clientSocket object.
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            // Creates a new PrintWriter object that writes to the output stream of the clientSocket object.
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));

            // Constructs the message for sending to server by concatenating the values of the choice, id, and value parameters.
            String m = choice + "," + id + "," + value;

            // Send the response back to the client
            out.println(m);

            // Flushes the PrintWriter to ensure that all characters are written to the output stream.
            out.flush();

            res = in.readLine(); // read a line of data from the stream
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        }

        return Integer.parseInt(res);
    }
}
