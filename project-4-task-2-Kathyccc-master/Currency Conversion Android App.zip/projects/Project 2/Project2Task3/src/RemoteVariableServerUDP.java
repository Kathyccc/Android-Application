/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This class implements a server using UDP that performs addition for the client.
 * It maps each user ID to the value of a sum.
 * The server operate addition, subtraction and get the value of current sum for each user.
 */
import java.net.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class RemoteVariableServerUDP {
    private static Map<Integer, Integer> map = new TreeMap<>();

    /**
     * The main method creates a new DatagramSocket and listens for incoming requests. When a request is received,
     * the appropriate operation is performed on the requested variable and the result is sent back to the client.
     *
     * @param args the command line arguments (not used)
     */
    public static void main(String args[]) {
        DatagramSocket aSocket = null;

        System.out.println("Server started");

        // Set the port number for the server
        System.out.println("Please enter server port: ");
        Scanner sc = new Scanner(System.in);
        int serverPort = sc.nextInt();

        byte[] buffer = new byte[1000];
        try {
            // Create a new DatagramSocket object to listen on the input port number
            aSocket = new DatagramSocket(serverPort);

            // Create a DatagramPacket object to hold incoming packets
            DatagramPacket request = new DatagramPacket(buffer, buffer.length);

            while (true) {
                // Wait for an incoming packet and store it in the request DatagramPacket object
                aSocket.receive(request);

                // Convert the reply packet data to integers
                ByteBuffer replyBuffer = ByteBuffer.wrap(request.getData(), 0, request.getLength());
                int choice = replyBuffer.getInt();
                int id = replyBuffer.getInt();

                System.out.println("User ID: " + id);

                int res;

                if(choice == 1){
                    System.out.println("Operation request: add");
                    int value = replyBuffer.getInt();
                    res = add(id, value);
                    System.out.println("The value being returned: " + res + "\n");

                } else if(choice == 2){
                    System.out.println("Operation request: subtract");
                    int value = replyBuffer.getInt();
                    res = subtract(id, value);
                    System.out.println("The value being returned: " + res+ "\n");

                } else {
                    System.out.println("Operation request: get");
                    res = get(id);
                    System.out.println("The value being returned: " + res+ "\n");

                }

                // Convert the result back to a byte array using ByteBuffer
                // reference: https://stackoverflow.com/questions/6374915/java-convert-int-to-byte-array-of-4-bytes
                byte[] data = ByteBuffer.allocate(4).putInt(res).array();

                // Create a new DatagramPacket object with the received data and sender's address and port
                DatagramPacket reply = new DatagramPacket(data, data.length, request.getAddress(), request.getPort());

                // Send the reply packet back to the sender
                aSocket.send(reply);
            }
            // Catch and handle SocketException if it occurs
        } catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());

            // Catch and handle IOException if it occurs
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());

            // Close the DatagramSocket object in the finally-block
            // To ensure that the socket is always closed properly
        } finally {
            if (aSocket != null) {
                aSocket.close();
            }
        }
    }

    /**
     * Adds the specified value to the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be added to the current value associated with the ID
     * @return the new value associated with the ID after the addition
     */
    public static int add(int id, int value){
        map.put(id, map.getOrDefault(id, 0) + value);
        return map.get(id);
    }

    /**
     * Subtracts the specified value from the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be updated
     * @param value the value to be subtracted from the current value associated with the ID
     * @return the new value associated with the ID after the subtraction
     */
    public static int subtract(int id, int value){
        map.put(id, map.getOrDefault(id, 0) - value);
        return map.get(id);
    }

    /**
     * Retrieves the current value associated with the given ID in the map.
     * If there is no entry for the given ID, the value is assumed to be 0.
     *
     * @param id the ID associated with the value to be retrieved
     * @return the current value associated with the ID
     */
    public static int get(int id){
        return map.getOrDefault(id, 0);
    }
}

