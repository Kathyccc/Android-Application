/**
 * Author: Kathy Chiang
 * Last Modified: February 22, 2023
 *
 * This class implements a client for a remote variable server using UDP.
 * The client communicates with the server over a socket connection and
 * allows the user to add, subtract or get a value associated with an ID.
 * The client presents a menu to the user for each interaction and waits for
 * user input. The client sends a request to the server based on user input
 * and displays the result received from the server.
 */
import java.net.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Scanner;

public class RemoteVariableClientUDP {
    // Initialize the DatagramSocket object to null
    static DatagramSocket aSocket = null;
    static int port;
    static boolean run = true;
    static InetAddress aHost;

    /**
     * The main method of the RemoteVariableClientUDP class prompts the user for a server
     * port and provides a menu for the user to add or subtract from an ID's sum or to retrieve
     * the sum. It sends the appropriate request to the server and displays the result returned
     * by the server.
     *
     * @param args command-line arguments, not used in this program
     */
    public static void main(String args[]) {
        System.out.println("The client is running.");

        // Prompt user to enter port number to listen on
        System.out.println("Please enter server port: ");
        Scanner sc = new Scanner(System.in);
        port = sc.nextInt();

        try {
            // Create a new DatagramSocket object for sending and receiving packets
            aSocket = new DatagramSocket();

            // Get the address of the server
            aHost = InetAddress.getByName("localhost");

            boolean run = true;

            // Loop to prompt user for menu choice, id, value to add or subtract until the user enter 4, which will set b to false
            while (run) {
                // Print menu to user
                System.out.println("1. Add a value to your sum.\n" +
                        "2. Subtract a value from your sum.\n" +
                        "3. Get your sum.\n" +
                        "4. Exit client.");

                // Take user input for menu choice
                int choice = sc.nextInt();

                // Initialize variables for later use
                int replyInt;
                int id;
                int value;

                // Process user's choice
                switch(choice) {
                    case 1:
                        // User chooses to add a value to their sum
                        System.out.println("Enter value to add: ");
                        value = sc.nextInt();

                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);
                        System.out.println("The result is " + replyInt + ".\n");
                        break;

                    case 2:
                        // User chooses to subtract a value from their sum
                        System.out.println("Enter value to subtract: ");
                        value = sc.nextInt();

                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        // Send request to server and get response
                        replyInt = operationRequest(choice, id, value);

                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 3:
                        // User chooses to get their sum
                        System.out.println("Enter your ID: ");
                        id = sc.nextInt();

                        /*
                        Send request to server and get response
                        Set the value to zero because it won't be used for get operation
                         */
                        replyInt = operationRequest(choice, id, 0);

                        System.out.println("The result is " + replyInt + ".\n");

                        break;

                    case 4:
                        // User chooses to exit client
                        run = false;
                        break;

                    default:
                        // User inputs invalid choice
                        System.out.println("Please choose from the menu");
                        break;
                }

                // If user has chosen to exit, break out of loop
                if(!run){
                    break;
                }
            }
            // Catch and handle SocketException if it occurs
        } catch (SocketException e) {
            System.out.println("Socket Exception: " + e.getMessage());
            // Catch and handle IOException if it occurs
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());

            // Close the DatagramSocket object in the finally-block
        } finally {
            if (aSocket != null) {
                System.out.println("Client side quitting. The remote variable server is still running.\n");
                aSocket.close();
            }
        }
    }

    /**
     * Sends a request to a server over a network connection and returns the response.
     * Each request asks the server to do "add" or "subtract" or "get"
     * Receive the operation results from the server's reply
     *
     * @param choice the choice associated with the request
     * @param id the ID associated with the request
     * @param value the value associated with the request
     * @return the response from the server
     */
    public static int operationRequest(int choice, int id, int value){
        // reference: https://www.geeksforgeeks.org/java-nio-bytebuffer-class-in-java/
        ByteBuffer buf = ByteBuffer.allocate(12);

        // Put the 'choice' and 'id' into ByteBuffer
        buf.putInt(choice);
        buf.putInt(id);
        if(choice != 3)
            buf.putInt(value);

        // Returns a byte array that backs the buffer
        byte[] data = buf.array();

        // Initialize the result to be zero
        int replyInt = 0;

        // Create a DatagramPacket object to send the message to the server
        DatagramPacket request = new DatagramPacket(data, data.length, aHost, port);

        try {
            // Pass values to server
            aSocket.send(request);

            // Create a new DatagramPacket object to hold the server's reply
            byte[] buffer = new byte[100];
            DatagramPacket reply = new DatagramPacket(buffer, buffer.length);

            // Wait for a reply from the server and store it in the reply DatagramPacket object
            aSocket.receive(reply);

            // Convert the reply packet data to a string and print it to the console
            replyInt = ByteBuffer.wrap(reply.getData(), 0, request.getLength()).getInt();
        } catch (IOException e) {
            System.out.println("IO Exception: " + e.getMessage());
        }

        return replyInt;
    }
}
