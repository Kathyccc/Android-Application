package ds.project1task1;

import java.io.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import jakarta.xml.bind.DatatypeConverter;

@WebServlet(name = "HashingServlet",
        urlPatterns = {"/computeHashes"})
public class ComputeHashes extends HttpServlet {
    public String message;

    @Override
    public void init() {
        message = "The hash of your input: ";
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // get the input text data and the chosen hash function
        String input = request.getParameter("inputText");
        String hashType = request.getParameter("hashFunction");

        String nextView;
        /*
         * Check if the search parameter is present.
         * If not, then give the user instructions and prompt for a search string.
         * If there is a search parameter, then do the search and return the result.
         */
        if (hashType != null) {
            if (hashType.equals("SHA-256")) {
                try {
                    // Access MessageDigest class for SHA-265
                    MessageDigest md = MessageDigest.getInstance("SHA-256");

                    // Complete the digest
                    // Compute hash and convert to two forms: hex and base64
                    md.update(input.getBytes());

                    // digest() method is called to calculate message digest of an input digest() return array of byte
                    String sha_base64 = DatatypeConverter.printBase64Binary(md.digest());
                    String sha_hex = DatatypeConverter.printHexBinary(md.digest());

                    request.setAttribute("shab", sha_base64);
                    request.setAttribute("shah", sha_hex);

                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            } else{
                try {

                    // Static getInstance method is called with hashing MD5
                    MessageDigest md = MessageDigest.getInstance("MD5");

                    // Complete the digest
                    // Compute hash and convert to two forms: hex and base64
                    md.update(input.getBytes());

                    // digest() method is called to calculate message digest of an input digest() return array of byte
                    String md5_base64 = DatatypeConverter.printBase64Binary(md.digest());
                    String md5_hex = DatatypeConverter.printHexBinary(md.digest());

                    request.setAttribute("md5b", md5_base64);
                    request.setAttribute("md5h", md5_hex);

                } catch (NoSuchAlgorithmException e) {
                    throw new RuntimeException(e);
                }
            }

            // Pass the user input to the view.
            nextView = "result.jsp";
        }
        else {
            // no input text so choose the prompt view
            nextView = "index.jsp";
        }

        // Transfer control over the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
