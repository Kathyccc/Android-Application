package ds.project1task3;

public class ClickerModel {
    private int countA = 0, countB = 0, countC = 0, countD = 0;

    public void countAns(String ans){

        if(ans.equals("A"))
            countA++;
        else if(ans.equals("B"))
            countB++;
        else if(ans.equals("C"))
            countC++;
        else
            countD++;
    }

    public int getCountA() {
        return countA;
    }

    public int getCountB() {
        return countB;
    }

    public int getCountC() {
        return countC;
    }

    public int getCountD() {
        return countD;
    }

    public void setCountA(int countA) {
        this.countA = countA;
    }

    public void setCountB(int countB) {
        this.countB = countB;
    }

    public void setCountC(int countC) {
        this.countC = countC;
    }

    public void setCountD(int countD) {
        this.countD = countD;
    }
}
