/**
 * Author: Kathy Chiang
 *
 * The 'CurrencyController' class provides methods for fetching currency conversion rates from an external API,
 * storing the rates in a MongoDB database, and computing statistics on the rates, such as the most frequently
 * converted currencies and the average response time of API calls.
 */

package cmu.ds.project4;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class CurrencyModel {

    // A map to keep track of the frequency of source currencies in the database
    Map<String, Integer> freq = new HashMap<>();

    /**
     * Fetches data from a specified URL using HTTP GET request and returns the response as a string.
     *
     * @param urlString the URL to fetch data from
     * @return the response from the specified URL as a string
     */
    public String fetch (String urlString){

        String response = "";
        try {
            // Create a new URL object and open a connection to the specified URL
            URL url = new URL(urlString);
            // making request to Http and build connection
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Check the status code of the HTTP response
            int statusCode = connection.getResponseCode();

            if (statusCode == HttpURLConnection.HTTP_OK) {
                // If the status code is 200 OK, read the response text from the connection input stream
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                String str;

                // Read each line of text from the input stream and add it to the response string
                while ((str = in.readLine()) != null) {
                    // str is one line of text readLine() strips newline characters
                    response += str;
                }
                in.close();
            } else {
                // If the status code is not 200 OK, set the response string to an error message
                response = "Error: " + statusCode;
            }

        } catch (IOException e) {
            // If an IO exception occurs, set the response string to an error message
            response = "Error: " + e.getMessage();
        }

        return response;
    }

    /**
     * Writes a document to a specified MongoDB collection.
     *
     * @param document the document to write to the collection
     * @param collectionName the name of the collection to write the document to
     *
     */
    public void writeDB(Document document, String collectionName){
        // Create a new MongoDB client and connect to the database
        // Reference: MongoDB
        ConnectionString connectionString = new ConnectionString("mongodb://kathyc:Maymay200350@ac-0hct8lu-shard-00-00.jguatnm.mongodb.net:27017,ac-0hct8lu-shard-00-01.jguatnm.mongodb.net:27017,ac-0hct8lu-shard-00-02.jguatnm.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();

        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("currencies");
        MongoCollection<Document> collection = database.getCollection(collectionName);

        // Insert the Document into the MongoDB collection
        collection.insertOne(document);

        mongoClient.close();
    }

    /**
     * Retrieves documents from a specified MongoDB collection and updates the frequency map with the frequency
     * of source currencies.
     *
     * @param collectionName the name of the collection to retrieve documents from
     * @return a list of documents retrieved from the specified collection
     */
    public List<Document> getFromDB(String collectionName){
        // Reference: MongoDB
        // Create a new MongoDB client and connect to the database
        ConnectionString connectionString = new ConnectionString("mongodb://kathyc:Maymay200350@ac-0hct8lu-shard-00-00.jguatnm.mongodb.net:27017,ac-0hct8lu-shard-00-01.jguatnm.mongodb.net:27017,ac-0hct8lu-shard-00-02.jguatnm.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        MongoDatabase database = mongoClient.getDatabase("currencies");
        MongoCollection<Document> collection = database.getCollection(collectionName);

        // Retrieve logs from MongoDB collection
        List<Document> logs = collection.find().into(new ArrayList<>());

        // count the frequency of each source currency
        for(Document log : logs) {
            if(log.containsKey("from")) {
                String from = log.getString("from");
                freq.put(from, freq.getOrDefault(from, 0) + 1);
            }
        }

        return logs;
    }

    /**
     * This method computes the average time taken for a series of operations
     * based on a list of time measurements.
     *
     * @param times A list of time measurements for a series of operations.
     * @return The average time taken for the operations.
     */
    public long computeAverageTime(List<Long> times) {
        // Initialize variables for sum and average
        long ave, sum = 0;

        // Compute the sum of all time measurements in the list
        for(long time : times) {
            sum += time;
        }

        // Compute the average time by dividing the sum by the number of measurements
        ave = sum / times.size();

        return ave;
    }

    /**
     * This function uses a priority queue to keep track of the top 5 popular currencies
     * based on their frequency of conversion. It iterates through the frequency map and adds each entry to the priority queue
     *
     * @return A list of top 5 most popular currencies
     */
    public List<String> getTopCurrencies() {
        // Initialize an empty list to store the top currencies
        List<String> topCurrencies = new ArrayList<>();

        // Create a priority queue to hold the entries in the frequency map sorted by their value (frequency)
        PriorityQueue<Map.Entry<String, Integer>> pq = new PriorityQueue<>(Comparator.comparingInt(Map.Entry::getValue));

        // Extract the top 5 most popular currencies from the result
        for (Map.Entry<String, Integer> entry : freq.entrySet()) {
            pq.offer(entry);

            // If the priority queue size exceeds 5, remove the entry with the lowest frequency (i.e., the least popular currency)
            if (pq.size() > 5) {
                pq.poll();
            }
        }

        // Iterate through the entries in the priority queue (which are now the top 5 most popular currencies) and add them to the topCurrencies list
        while (!pq.isEmpty()) {
            topCurrencies.add(0, pq.poll().getKey());
        }

        return topCurrencies;
    }
}
