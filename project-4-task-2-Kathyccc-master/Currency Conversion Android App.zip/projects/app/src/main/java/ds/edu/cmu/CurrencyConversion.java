/**
 *
 * Author: Kathy Chiang
 * Date: 04/07/2023
 *
 * The CurrencyConversion class is an activity in an Android app that facilitates currency conversion.
 * It includes an onCreate() method that sets up the layout of the activity and adds a listener to
 * the "submit" button. When the button is clicked, the method retrieves the source, target, and amount
 * values entered by the user, creates a new GetRate object, and calls the search() method to search for
 * the rate asynchronously in another thread. The results of the search are returned via a callback interface.
 *
 * The class also includes a conversionComplete() method that is called when the currency conversion is complete.
 * It updates the UI with the converted amount and exchange rate if the conversion was successful, or displays
 * an error message if the currency entered by the user is not supported.
 */
package ds.edu.cmu;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class CurrencyConversion extends AppCompatActivity {

    // create an object of CurrencyConversion
    CurrencyConversion me = this;

    /**
     * This method sets up the main activity by setting the content view to activity_main.xml and
     * adding a listener to the "submit" button to initiate the currency conversion. When the button is clicked,
     * it gets the source, target, and amount values entered by the user, creates a new GetRate object, and calls
     * the search() method of the GetRate object to search for the rate asynchronously in another thread.
     * It then passes in the source, target, amount, and CurrencyConversion objects as parameters to the search() method.
     * The results of the search are returned via a callback interface.
     *
     * @param savedInstanceState The saved instance state of the activity.
     *
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // set the content view of the activity to activity_main.xml
        setContentView(R.layout.activity_main);

        // create a final object of CurrencyConversion
        final CurrencyConversion ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);

        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){

            // Implement the onClick() method to handle button clicks
            public void onClick(View viewParam) {
                // Get the source, target, and amount values entered by the user
                String source = ((EditText)findViewById(R.id.sourceCurrency)).getText().toString();
                String target = ((EditText)findViewById(R.id.targetCurrency)).getText().toString();
                String amount = ((EditText)findViewById(R.id.amount)).getText().toString();

                // Print the source, target, and amount values to the console
                System.out.println("Source Currency = " + source);
                System.out.println("Target Currency = " + target);
                System.out.println("Amount = " + amount);

                // Create a new GetRate object to get the currency conversion rate
                GetRate gr = new GetRate();

                // Call the search() method of the GetRate object to search for the rate asynchronously in another thread
                // and pass in the source, target, amount, and CurrencyConversion objects as parameters
                gr.search(source, target, amount, me, ma); // Done asynchronously in another thread.  It calls ip.pictureReady() in this thread when complete.
            }
        });
    }

    /**
     * This method is called when the currency conversion is complete. It updates the UI with the
     * converted amount and exchange rate if the conversion was successful, or displays an error message
     * if the currency entered by the user is not supported.
     *
     * @param convertedAmount The converted amount if the conversion was successful, or null if not.
     * @param rate The exchange rate used for the conversion
     */
    public void conversionComplete(String convertedAmount, String rate) {

        // Find the views in the activity's layout
        TextView sourceView = (EditText)findViewById(R.id.sourceCurrency);
        TextView targetView = (EditText)findViewById(R.id.targetCurrency);
        TextView amountView = (EditText)findViewById(R.id.amount);
        TextView feedbackView = findViewById(R.id.feedback);

        // If the converted amount is not null, set the feedback text to display the conversion result and rate
        if (convertedAmount != null) {
            feedbackView.setText(sourceView.getText().toString() + " " + amountView.getText().toString() + " = " + targetView.getText().toString() + " "  + convertedAmount + ".\n The currency rate is " + rate);

            // Make the feedback view visible
            feedbackView.setVisibility(View.VISIBLE);

        // If the input currency is not supported
        } else {
            // Otherwise, set the feedback text to display an error message
            feedbackView.setText("Sorry, the currency you typed is not supported.");
            System.out.println("currency not supported");

            // Make the feedback view visible
            feedbackView.setVisibility(View.VISIBLE);
        }

        // Clear the source, target, and amount views
        sourceView.setText("");
        targetView.setText("");
        amountView.setText("");
    }
}