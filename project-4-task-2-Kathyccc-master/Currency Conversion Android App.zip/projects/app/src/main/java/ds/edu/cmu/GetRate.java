/**
 *
 * Author: Kathy Chiang
 * Date: 04/07/2023
 *
 * This class performs a currency conversion by making an HTTP GET request to a currency conversion API.
 * The class uses a callback interface to return the converted amount and exchange rate to the calling activity.
 * The HTTP request is performed on a background thread to avoid blocking the UI thread.
 *
 * Method BackgroundTask.doInBackground( ) does the background work
 * Method BackgroundTask.onPostExecute( ) is called when the background work is
 * done; it calls *back* to ip to report the results
 */
package ds.edu.cmu;

import android.app.Activity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import com.google.gson.Gson;
import com.google.gson.JsonObject;


public class GetRate {
   CurrencyConversion cc = null;   // for callback
    String sourceCurrency = null;
    String targetCurrency = null;
    String givenAmount = null;
    String convertedAmount = null;
    String rate = null;

    /**
     * This method initiates a currency conversion by calling a background task to perform an HTTP GET request
     * to the currency conversion API. The converted amount and exchange rate are returned via a callback interface
     * when the HTTP request is complete.
     *
     * @param sourceCurrency The source currency code.
     * @param targetCurrency The target currency code.
     * @param givenAmount The amount of the source currency to convert.
     * @param activity The calling activity.
     * @param cc The callback interface to return the converted amount and exchange rate.
     */
    public void search(String sourceCurrency, String targetCurrency, String givenAmount, Activity activity, CurrencyConversion cc) {
        this.cc = cc;
        this.sourceCurrency = sourceCurrency;
        this.targetCurrency = targetCurrency;
        this.givenAmount = givenAmount;

        new BackgroundTask(activity).execute();
    }

    /**
     * This inner class implements a background thread for a long running task that should not be performed on the UI thread.
     * It creates a new Thread object, then calls doInBackground() to actually do the work.
     * When done, it calls onPostExecute(), which runs on the UI thread to update some UI widget (never update a UI
     * widget from some other thread!).
     */
    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        /**
         * This method starts a new background thread to perform the HTTP GET request.
         */
        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        /**
         * This method starts the background task.
         */
        private void execute(){
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        /**
         * This method implements whatever needs to be done on the background thread.
         * It performs an HTTP GET request to the currency conversion API using the source and target currencies
         * and the given amount.
         */
        private void doInBackground() {
            search(sourceCurrency, targetCurrency, givenAmount);
        }

        /**
         * This method runs on the UI thread after the background thread completes.
         * It returns the converted amount and exchange rate to the calling activity via the callback interface.
         */
        public void onPostExecute() {
            cc.conversionComplete(convertedAmount, rate);
            System.out.println("convertedAmount: " + convertedAmount + " rate: " + rate);
        }

        /**
         * This method performs an HTTP GET request to the currency conversion API using the source and target currencies
         * and the given amount.
         * The response is parsed using the Gson library, and the converted amount and exchange rate are extracted from
         * the response.
         *
         * @param sourceCurrency The source currency code.
         * @param targetCurrency The target currency code.
         * @param givenAmount The amount of the source currency to convert.
         *
         */
        private void search(String sourceCurrency, String targetCurrency, String givenAmount) {

            // Construct the URL for the web service
            String urlString = "https://kathyccc-miniature-robot-67r4wppg93jrj-8080.preview.app.github.dev/currencies?from="  + sourceCurrency + "&to=" + targetCurrency + "&amount=" + givenAmount;

            String response = "";

            System.out.println("url: " + urlString);

            // Send the HTTP GET request
            try {
                URL url = new URL(urlString);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");

                int responseCode = connection.getResponseCode();

                // If the response code is OK, read the response
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
                    String str;

                    // Read each line of the response and append it to the response string
                    while ((str = in.readLine()) != null) {
                        // str is one line of text readLine() strips newline characters
                        response += str;
                    }
                    in.close();
                } else {
                    // If the response code is not OK, set the response string to an error message
                    response = "Error: " + responseCode;
                }
            } catch (IOException e) {
                // If there is an IO exception, set the response string to an error message
                response = "Error: " + e.getMessage();
            }

            // Print the response to the console
            System.out.println("response: " +  response);

            // If the response contains an error message, set the converted amount to null
            if(response.contains("Error")) {
                convertedAmount = null;
            } else {
                // If the response is successful, parse the JSON and extract the conversion rate and converted amount
                Gson gson = new Gson();
                JsonObject jsonResponse = gson.fromJson(response, JsonObject.class);
                String result = jsonResponse.get("result").getAsString();

                rate = jsonResponse.get("rate").getAsString();
                convertedAmount = jsonResponse.get("convertedAmount").getAsString();
            }
        }
    }
}
