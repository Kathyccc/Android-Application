/**
 * Author: Kathy Chiang
 *
 * This class is a Java Servlet that provides a RESTful API for currency conversion.
 * The doGet method handles incoming GET requests from clients.
 * If the request is for currency conversion, the servlet fetches currency conversion
 * data from an API endpoint, parses the JSON response, and sends a JSON-formatted response
 * back to the client. The servlet also computes the response time for the currency conversion
 * request and stores the search logs in a MongoDB database. If the request is for the dashboard,
 * the servlet retrieves the search logs and other data from the database and computes the
 * average response time for all currency conversion requests.
 */
package cmu.ds.project4;

import com.google.gson.JsonObject;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;
import org.bson.Document;

@WebServlet(name = "CurrencyServlet",
        urlPatterns = {"/currencies", "/dashboard"})
public class CurrencyServlet extends HttpServlet{

    // API access key
    private static final String ACCESS_KEY = "04dc2e97f1ef49c0170a3317";
    CurrencyModel model;
    List<Long> Times = new ArrayList<>();

    // Initialize the servlet
    @Override
    public void init() {
        model = new CurrencyModel();
    }

    /**
     * Overrides the doGet() method to handle incoming GET requests from clients.
     *
     * @param request  the HTTP request sent by the client
     * @param response the HTTP response returned to the client
     * @throws IOException if there is an error while reading/writing to the response
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // If the request is for currency conversion
        if(request.getServletPath().equals("/currencies")) {
            long startTime = System.currentTimeMillis();

            // Get the currency codes and amount from the request parameters
            String from = request.getParameter("from");
            String to = request.getParameter("to");
            int givenAmount = Integer.parseInt(request.getParameter("amount"));

            // API endpoint for currency conversion
            String url = "https://v6.exchangerate-api.com/v6/" + ACCESS_KEY + "/pair/" + from + "/" + to + "/" + givenAmount;

            System.out.println("url: " + url);

            // Fetch data from the API endpoint using HttpsURLConnection
            String json = model.fetch(url);

            System.out.println("json: " + json);

            // Parse JSON response using Gson library
            /* Reference: https://stackoverflow.com/questions/2845599/how-do-i-parse-json-from-a-java-httpresponse */
            Gson gson = new Gson();
            JsonObject jsonResponse = gson.fromJson(json, JsonObject.class);

            // Parse the response from the API. The 'result' is either "success" or "error"
            String result = jsonResponse.get("result").getAsString();

            // JSON formatted response to the Android application
            JsonObject resp = new JsonObject();

            // Create a Document object with the rates data
            Document document = new Document();

            // If the conversion was successful
            if (result.equals("success")) {

                String rate = jsonResponse.get("conversion_rate").getAsString();
                String convertedAmount = jsonResponse.get("conversion_result").getAsString();
                String time_last_update = jsonResponse.get("time_last_update_utc").getAsString();

                // Add the converted amount and other data to the JSON response object
                resp.addProperty("result", result);
                resp.addProperty("rate", rate);
                resp.addProperty("convertedAmount", convertedAmount);
                resp.addProperty("time_last_update", time_last_update);

                String jsonString = resp.toString();

                // Set response content type to plain text and send the converted amount as a string
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                request.setAttribute("response", jsonString);

                System.out.println("response: " + jsonString);

                // Compute the response time and add it to the list
                long endTime = System.currentTimeMillis();
                long responseTime = endTime - startTime;
                Times.add(responseTime);

                // Add the fields to the document
                document.append("Result", result);
                document.append("Search Time", new Date());
                document.append("Last Update Time", time_last_update);
                document.append("from", from);
                document.append("to", to);
                document.append("rate", rate);
                document.append("givenAmount", givenAmount);
                document.append("convertedAmount", convertedAmount);
                document.append("responseTime", responseTime);

                // Write the data to the database
                model.writeDB(document, "currencySearch");

            } else {
                // If the conversion was not successful, add the error message to the JSON response object
                resp.addProperty("result", result);

                // Convert the JSON response to String
                String jsonString = resp.toString();

                // Set response content type to plain text and send the converted amount as a string
                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                request.setAttribute("response", jsonString);

                // Add the fields to the document
                document.append("Result", result);
                document.append("Search Time", new Date());

                // Write the data to the database
                model.writeDB(document, "currencySearch");
            }

            // Get the currency conversion result page and forward the request and response objects to it
            RequestDispatcher view = request.getRequestDispatcher("currency.jsp");
            try {
                view.forward(request, response);
            } catch (ServletException e) {
                System.out.println(e.getMessage());
            }
        }
        // If the request is for dashboard, get the search logs and other data for the dashboard view
        else {
            List<Document> logs = model.getFromDB("currencySearch");

            // Compute the average response time for all currency conversion requests
            long aveResponseTime = model.computeAverageTime(Times);

            // Get the top 5 most popular currency pairs searched for
            List<String> popularCurrencies = model.getTopCurrencies();

            // Set the request attributes with the data to be displayed in the dashboard view
            request.setAttribute("logs", logs);
            request.setAttribute("search_num", logs.size());
            request.setAttribute("aveResponseTime", aveResponseTime);
            request.setAttribute("popularCurrencies", popularCurrencies);

            // Transfer control over the correct "view"
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            try {
                view.forward(request, response);
            } catch (ServletException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
